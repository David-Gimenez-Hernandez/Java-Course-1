import java.util.Arrays;

class BusquedaBinaria {



//MOTIVACION BUSQUEDA BINARIA: el logaritmo en base 2 de un millon es algo menos de 20




  static   boolean  busquedaBinaria(int[]  v, int elem){
    return false;
  }

//HACED TAMBIEN LA VERSION RECURSIVA

  static   boolean  binariaRecursiva(int[]  v, int elem){
    return false;
  }


////////////////////////////////////////  NO TOCAR DE AQUI EN ADELANTE

 private static void do_check(int[] arr, int elem, boolean solucion){
  try{
   boolean solAlumno = busquedaBinaria(arr,elem);
   if (solAlumno!=solucion){
    System.out.println("Error: el codigo del alumno produce un resultado incorrecto");
    System.out.println("El resultado esperado para el array  " + Arrays.toString(arr) + ", y el elemento " + elem + ", ");
    System.out.println("deberia ser " + solucion);
    System.out.println("pero el resultado obtenido es " + solAlumno);
    throw new Error("");
    
   }
  } catch (Exception e){
   System.out.println(e.toString());
   throw new Error("Error en test: el codigo del alumno produce una excepcion");
  }
 }
 
 
 public static void main(String[] args) {
  {
   int[] arr = {};
   int elem = 4;
   boolean solucion = false;
   do_check(arr, elem, solucion);
  }
  {
   int[] arr = {1};
   int elem = 4;
   boolean solucion = false;
   do_check(arr, elem, solucion);
  }
  {
   int[] arr = {4};
   int elem = 4;
   boolean solucion = true;
   do_check(arr, elem, solucion);
  }
  {
   int[] arr = {1,2,3};
   int elem = 4;
   boolean solucion = false;
   do_check(arr, elem, solucion);
  }
  {
   int[] arr = {1,2,3,4,5};
   int elem = 1;
   boolean solucion = true;
   do_check(arr, elem, solucion);
  }
  {
   int[] arr = {1,2,3,4,5,6};
   int elem = 4;
   boolean solucion = true;
   do_check(arr, elem, solucion);
  }
  {
   int[] arr = {5,6,7,8,9};
   int elem = 4;
   boolean solucion = false;
   do_check(arr, elem, solucion);
  }
  {
   int[] arr = {1,2,3,4,5};
   int elem = 5;
   boolean solucion = true;
   do_check(arr, elem, solucion);
  }
  
  System.out.println("Test  busqueda binaria finalizado correctamente.");
 }
 
}
